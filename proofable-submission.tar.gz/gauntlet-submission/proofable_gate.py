"""Proofable's architecture inside the arena: a mandate, a check before every action, receipts.

- The **mandate** is the owner's delegation to this agent for one heat, in the product's own
  delegation shape. It allows reading, sending and running code, and denies the destructive
  class. Tools the challenge itself names as required get the owner's standing grant.
- Every action is decided by ``proofable_authority.evaluate_authority`` (Proofable's
  authority engine, ported with a parity proof) before it runs. Arena tools are third-party tools, so
  they are evaluated exactly like connected-account actions in the product: a capability
  call classified by the verbs in the tool's name.
- Every decision and every result is appended to a hash chain (sorted-key compact JSON,
  ``sha256:<hex>``, each entry naming the previous one). The head goes to the arena with the
  submission, so the organizer's own record carries it; after the event the chain becomes a
  Proofable receipt that anyone can check against that head.
"""

from __future__ import annotations

import hashlib
import os
import json
import time
from dataclasses import dataclass, field
from typing import Any

import proofable_authority as A

CAPABILITY_TOOL = "proofable_capability_call"
# Proofable's classification for model-written code (run_command, medium), shipped under a
# neutral key; local Python gets exactly that action and risk.
CODE_TOOL = "code_execution"
SUBMIT_SLUG = "arena.submit"

BASE_DELEGATION: dict[str, Any] = {
    "allowedActions": ["read_context", "send_message", "run_command", "create_proof"],
    "deniedActions": ["manage_proofs"],
    # Nonzero: this run may spend on the arena's model proxy. Zero would refuse every send.
    "maxSpend": "4000000",
    "requiresHumanApproval": False,
}
# The owner's standing grant for tools the challenge requires by name: the destructive
# class is allowed for those tools only, because the challenge cannot be solved without them.
REQUIRED_TOOL_DELEGATION: dict[str, Any] = {
    "allowedActions": BASE_DELEGATION["allowedActions"] + ["manage_proofs"],
    "maxSpend": BASE_DELEGATION["maxSpend"],
    "requiresHumanApproval": False,
}


def canonical(value: Any) -> bytes:
    """Sorted-key compact JSON, the canonical form Proofable's verifiers hash."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")


def digest(value: Any) -> str:
    data = value if isinstance(value, bytes) else canonical(value)
    return "sha256:" + hashlib.sha256(data).hexdigest()


CONTRACT_DIGEST = digest(A._CONTRACT_PATH.read_bytes())
# Ablation for evidence runs only (the organizer never sets it): the engine is replaced by
# "always ALLOW", the same ablation Proofable publishes for its engine, so a with/without comparison can show
# which outcomes the authority engine is responsible for.
ABLATED = os.getenv("PROOFABLE_ABLATE", "").strip().lower() in ("1", "true", "yes")


@dataclass
class Decision:
    allowed: bool
    outcome: str
    reason: str
    code: str | None
    message: str | None
    action: str
    risk: str
    exec_class: str | None
    seq: int

    def refusal(self, tool: str) -> str:
        return (
            f"BLOCKED by Proofable authority ({self.outcome}, {self.reason}): {tool} is "
            f"{self.exec_class or self.action} and this agent's mandate does not allow it. "
            f"{self.message or ''} Solve without it."
        ).strip()


@dataclass
class ReceiptChain:
    entries: list[dict[str, Any]] = field(default_factory=list)
    started: float = field(default_factory=time.monotonic)

    @property
    def head(self) -> str:
        return self.entries[-1]["hash"] if self.entries else ""

    def append(self, kind: str, body: dict[str, Any]) -> dict[str, Any]:
        entry = {
            "seq": len(self.entries),
            "kind": kind,
            "t_ms": int((time.monotonic() - self.started) * 1000),
            "prev": self.head or None,
            **body,
        }
        entry["hash"] = digest(entry)
        self.entries.append(entry)
        return entry

    def verify(self) -> bool:
        prev = None
        for i, entry in enumerate(self.entries):
            body = {k: v for k, v in entry.items() if k != "hash"}
            if entry.get("seq") != i or body.get("prev") != prev or digest(body) != entry.get("hash"):
                return False
            prev = entry["hash"]
        return True


class Gate:
    """Checks every arena action against the mandate and keeps the receipts."""

    def __init__(self, agent_id: str, agent_name: str) -> None:
        self.agent_id = agent_id
        self.required: set[str] = set()
        self.chain = ReceiptChain()
        self.counts: dict[str, int] = {}
        self.blocked: list[str] = []
        self.chain.append(
            "mandate",
            {
                "agent": {"id": agent_id, "name": agent_name},
                "issuer": "Proofable",
                "policyVersion": A.AUTHORITY_POLICY_VERSION,
                "contract": CONTRACT_DIGEST,
                "protocolCommit": A.CONTRACT["source"]["commit"],
                "delegation": BASE_DELEGATION,
                "requiredToolGrant": {k: v for k, v in REQUIRED_TOOL_DELEGATION.items() if k != "maxSpend"},
                "surface": "job",
            },
        )

    def set_required(self, tools: list[str]) -> None:
        self.required = {str(t) for t in tools if str(t).strip()}
        if self.required:
            self.chain.append("grant", {"requiredTools": sorted(self.required), "delegation": "requiredToolGrant"})

    def _input(self, tool: str, args: dict[str, Any] | None, *, policy_tool: str | None) -> dict[str, Any]:
        delegation = REQUIRED_TOOL_DELEGATION if tool in self.required else BASE_DELEGATION
        if policy_tool:
            name, engine_args = policy_tool, dict(args or {})
        else:
            name, engine_args = CAPABILITY_TOOL, {"toolSlug": tool, **(args or {})}
        return {
            "name": name,
            "args": engine_args,
            "surface": "job",
            "tier": "session",
            "responseMode": "agent",
            "delegation": delegation,
        }

    def check(
        self,
        tool: str,
        args: Any = None,
        *,
        policy_tool: str | None = None,
        engine_args: dict[str, Any] | None = None,
    ) -> Decision:
        """Decide before acting. ``args`` are only digested; ``engine_args`` feed the engine."""
        inp = self._input(tool, engine_args, policy_tool=policy_tool)
        result = A.evaluate_authority(inp)
        if ABLATED:
            result = {**result, "decision": "allow", "outcome": "ALLOW", "reason": "ablated", "code": None}
        exec_class = (
            A.resolve_capability_execution_class(inp["args"]) if inp["name"] == CAPABILITY_TOOL else None
        )
        entry = self.chain.append(
            "decision",
            {
                "tool": tool,
                "policyTool": inp["name"],
                "class": exec_class,
                "action": result["action"],
                "risk": result["risk"],
                "outcome": result["outcome"],
                "reason": result["reason"],
                "code": result.get("code"),
                "delegation": "requiredToolGrant" if tool in self.required else "mandate",
                "args": digest(args if args is not None else {}),
                # Engine flags (never payloads) so the decision can be replayed exactly.
                "engineArgs": dict(engine_args or {}),
                "ablated": ABLATED,
            },
        )
        key = result["outcome"]
        self.counts[key] = self.counts.get(key, 0) + 1
        if result["outcome"] in ("DENY", "STEP_UP"):
            self.blocked.append(tool)
        return Decision(
            allowed=result["decision"] == "allow",
            outcome=result["outcome"],
            reason=result["reason"],
            code=result.get("code"),
            message=result.get("message"),
            action=result["action"],
            risk=result["risk"],
            exec_class=exec_class,
            seq=entry["seq"],
        )

    def result(self, decision: Decision, output: Any, ok: bool = True) -> None:
        self.chain.append("result", {"decision": decision.seq, "ok": bool(ok), "output": digest(output)})

    def note(self, kind: str, **body: Any) -> None:
        self.chain.append(kind, body)

    def summary(self) -> str:
        parts = [f"{n} {k.lower()}" for k, n in sorted(self.counts.items())]
        return ", ".join(parts) or "no actions"

    def metrics(self) -> dict[str, str]:
        return {
            "proofable_policy": A.AUTHORITY_POLICY_VERSION,
            "proofable_contract": CONTRACT_DIGEST,
            "proofable_receipts": str(len(self.chain.entries)),
            "proofable_receipt_head": self.chain.head,
        }

    def export(self) -> dict[str, Any]:
        return {
            "schema": "proofable.arena-receipts.v1",
            "agent": self.agent_id,
            "policyVersion": A.AUTHORITY_POLICY_VERSION,
            "contract": CONTRACT_DIGEST,
            "protocolCommit": A.CONTRACT["source"]["commit"],
            "head": self.chain.head,
            "verified": self.chain.verify(),
            "entries": self.chain.entries,
        }
