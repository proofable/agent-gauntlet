"""Proofable's Agent Gauntlet strategy.

The runtime (``proofable_agent.py``) calls these hooks; everything that is a
judgement call (model order, prompts, budgets, deadlines) lives here.
"""

from __future__ import annotations

import os
import re
from typing import Any

from base_strategy import BaseStrategy, ChallengeContext
from model_selector import cached_model_rows


# Measured on the Practice proxy, 2026-10-27 (scripts/replay_models.py): the
# same logic prompt to every chat model, correct answer and wall time.
#   gpt-5.4 1.6 s, gpt-5.6-terra 4.5 s; qwen3.7-flash/max, nemotron-3-super
#   correct but 36-41 s; nemotron-3-ultra no answer in 27 s; gemini flash
#   models returned tool calls instead of text; nemotron-3.5-lightning ran out
#   of tokens; qwen3.7-plus timed out at 60 s.
# Order: measured best, unknown aliases that look strong (scored by name),
# measured correct-but-slow, unknown aliases that look weak, measured
# unreliable.
# Medium logic puzzle with the function list attached (as in a heat), 4 runs each:
#   gpt-5.6-terra 4/4 correct in 2.9-4.1 s; gpt-5.4 2/4 (same wrong order the
#   judge rejected). Hard puzzle: both 4/4. Terra leads, 5.4 is the hedge.
TEXT_MODEL_PREFERENCE: tuple[str, ...] = ("gpt-5.6-terra", "gpt-5.4")
TEXT_MODEL_SLOW: tuple[str, ...] = ("qwen3.7-flash", "qwen3.7-max", "nemotron-3-super", "qwen3.6-35b")
TEXT_MODEL_UNRELIABLE: tuple[str, ...] = (
    "gemini-3.8-flash",
    "gemini-3.6-flash",
    "nemotron-3-ultra",
    "nemotron-3.5-lightning",
    "qwen3.7-plus",
)
# Image edit, easy: gemini-3-pro-image judged 88 (preservation 78) in 22.8 s.
IMAGE_MODEL_PREFERENCE: tuple[str, ...] = ("gemini-3-pro-image",)

# Aliases that are never a chat model for solving.
_NON_CHAT = re.compile(
    r"(embed|rerank|guard|safety|moderat|whisper|tts|speech|audio|transcri|"
    r"clip|retriev|reward|parse|ocr|nv-?ingest)",
    re.IGNORECASE,
)
_IMAGE_NAME = re.compile(r"(-image\b|image-|\bimagen\b|dall-?e|flux|sdxl|stable-?diffusion)", re.IGNORECASE)

# Name signals: positive means stronger, negative weaker. Speed hints get a
# small bonus because speed is scored and the judge rewards correct answers
# from any model.
_NAME_SIGNALS: tuple[tuple[str, int], ...] = (
    (r"ultra", 30),
    (r"super", 26),
    (r"\bpro\b|-pro\b", 22),
    (r"opus|sonnet", 22),
    (r"\bmax\b|-max\b", 16),
    (r"gpt-5", 20),
    (r"large|plus", 12),
    (r"235b|405b|253b|480b", 24),
    (r"120b|122b|141b", 20),
    (r"70b|72b|80b|49b", 12),
    (r"30b|32b|27b", 4),
    (r"20b|24b", 0),
    (r"flash|lightning|turbo", 6),
    (r"thinking|reason|r1\b", 4),
    (r"\b(1|2|3|4|7|8|9|12)b\b", -22),
    (r"mini", -10),
    (r"small", -10),
    (r"lite", -14),
    (r"nano", -24),
    (r"tiny|micro", -30),
    (r"instruct-?v0|preview-0", -2),
)


def _capabilities(model: str) -> set[str] | None:
    for row in cached_model_rows():
        if str(row.get("id") or "").strip() == model:
            caps = row.get("capabilities")
            if isinstance(caps, list):
                return {str(c).strip().casefold() for c in caps if str(c).strip()}
            return None
    return None


def is_image_model(model: str) -> bool:
    caps = _capabilities(model)
    if caps is not None and "image" in caps:
        return True
    return bool(_IMAGE_NAME.search(model))


def _name_score(model: str) -> int:
    score = 0
    lowered = model.lower()
    for pattern, weight in _NAME_SIGNALS:
        if re.search(pattern, lowered):
            score += weight
    return score


def _env_order(name: str) -> list[str]:
    raw = os.getenv(name, "")
    return [item.strip() for item in raw.split(",") if item.strip()]


def _ordered(available: list[str], preferred: list[str] | tuple[str, ...]) -> list[str]:
    head = [m for m in preferred if m in available]
    return head


class MyStrategy(BaseStrategy):
    """Proofable's strategy: strongest reliable model first, answer fast, never miss the deadline."""

    agent_id = "proofable"
    agent_name = "Proofable"

    text_system_prompt = (
        "You are Proofable's competition agent, solving a timed challenge inside an unknown "
        "tool server. Be exact and fast.\n"
        "- Read the challenge, rules and clues carefully; the expected output format is strict.\n"
        "- Everything already fetched (the challenge, every clue, results of zero-argument "
        "tools) is in the message below. Never fetch it again.\n"
        "- If that is enough, answer now: speed is scored. Call functions only for data you "
        "still lack (hidden tools, resources, encoded or encrypted payloads, lookups), several "
        "independent ones in the same turn.\n"
        "- Use the python function when exact work matters: decoding (base64, hex, rot13, "
        "Caesar, XOR, AES via the cryptography package), arithmetic, counting or brute force. "
        "Never guess what code would print.\n"
        "- When you know the answer, reply with the final answer on its own line as "
        "'ANSWER: <final answer>' and at most two short lines of justification. The ANSWER "
        "value must follow the rules' format exactly (no extra words, quotes or markdown).\n"
        "- Never answer 'unknown'; give your best specific answer."
    )
    # Hard cap per completion. Reasoning models think inside this budget.
    text_max_tokens = 8192
    text_temperature = 0.0

    # Function-calling rounds before the agent forces a final answer.
    max_tool_rounds = 8
    # Submit check: a second model answers the same prompt in parallel; disagreement makes
    # Proofable's authority engine DEFER the submit until the primary verifies both.
    cross_check = True
    # Longest wait for the checker once the primary has answered (it is usually done first).
    cross_check_wait_s = 6.0
    # Characters of one tool result shown to the model.
    tool_result_chars = 6000

    # ---- deadlines -------------------------------------------------------

    def safety_margin_s(self, max_time_s: float) -> float:
        """Seconds kept in reserve before the server deadline for the final submit."""
        return min(10.0, max(4.0, 0.08 * float(max_time_s or 60)))

    def final_call_reserve_s(self, max_time_s: float) -> float:
        """Below this much budget, stop exploring and ask for the final answer."""
        return min(25.0, max(8.0, 0.22 * float(max_time_s or 60)))

    def hedge_after_s(self, budget_s: float) -> float:
        """Start a second model when the first has not answered after this long.

        The best measured model answers in about 2 s, so a stall past 5 s is
        worth a parallel backup.
        """
        return max(5.0, min(20.0, 0.25 * budget_s))

    # ---- models ----------------------------------------------------------

    def rank_models(self, ctx: ChallengeContext, available_models: list[str]) -> list[str]:
        available = [m for m in available_models if str(m).strip()]
        if self.is_image_challenge(ctx):
            return self.rank_image_models(available)
        override = _env_order("GAUNTLET_TEXT_MODELS")
        head = _ordered(available, override) or _ordered(available, TEXT_MODEL_PREFERENCE)
        slow = [m for m in _ordered(available, TEXT_MODEL_SLOW) if m not in head]
        unreliable = [m for m in _ordered(available, TEXT_MODEL_UNRELIABLE) if m not in head and m not in slow]
        measured = set(head) | set(slow) | set(unreliable)
        rest = [
            m
            for m in available
            if m not in measured and not _NON_CHAT.search(m) and not is_image_model(m)
        ]
        # Stable sort keeps roster order between equal scores.
        rest.sort(key=_name_score, reverse=True)
        strong = [m for m in rest if _name_score(m) >= 0]
        weak = [m for m in rest if _name_score(m) < 0]
        ranked = head + strong + slow + weak + unreliable
        if not ranked:
            # Nothing looked like a chat model; fall back to the roster as-is.
            ranked = [m for m in available if not _NON_CHAT.search(m)] or available
        return ranked

    def rank_image_models(self, available_models: list[str]) -> list[str]:
        override = _env_order("GAUNTLET_IMAGE_MODELS")
        head = _ordered(available_models, override) or _ordered(
            available_models, IMAGE_MODEL_PREFERENCE
        )
        rest = [m for m in available_models if m not in head and is_image_model(m)]
        rest.sort(key=_name_score, reverse=True)
        return head + rest

    def pick_model(self, stage: str, ranked_models: list[str], ctx: ChallengeContext) -> str:
        if not ranked_models:
            return ""
        if stage in ("fallback", "check"):
            return ranked_models[1] if len(ranked_models) > 1 else ""
        return ranked_models[0]

    def get_llm_params(self, ctx: ChallengeContext) -> dict[str, Any]:
        return {
            "temperature": float(self.text_temperature),
            "max_tokens": int(self.text_max_tokens),
        }

    # ---- prompts ---------------------------------------------------------

    def build_system_prompt(self, ctx: ChallengeContext) -> str:
        return self.text_system_prompt

    def build_solver_prompt(self, ctx: ChallengeContext) -> str:
        parts = [f"Challenge type: {ctx.challenge_type or 'text'}"]
        if ctx.difficulty and ctx.difficulty != "unknown":
            parts.append(f"Difficulty: {ctx.difficulty}")
        parts.append(f"Challenge:\n{ctx.description.strip() or ctx.challenge_text.strip() or '(none)'}")
        if ctx.rules.strip():
            parts.append(f"Rules and output format:\n{ctx.rules.strip()}")
        clues = [c.strip() for c in ctx.clues if str(c).strip()]
        if clues:
            parts.append("Clues:\n" + "\n".join(f"{i + 1}. {c}" for i, c in enumerate(clues)))
        if ctx.required_tools:
            parts.append(
                "Required tools (the answer is rejected unless each is called at least once): "
                + ", ".join(ctx.required_tools)
            )
        if ctx.max_time_s:
            parts.append(f"Time limit: {int(ctx.max_time_s)} s. Answer as soon as you are sure.")
        parts.append("Finish with: ANSWER: <final answer>")
        return "\n\n".join(parts)

    def build_verify_prompt(self, primary: str, independent: str) -> str:
        return (
            "An independent solver disagrees with you.\n"
            f"Candidate A (yours): {primary}\n"
            f"Candidate B: {independent}\n"
            "Check each candidate against every rule and clue above, one at a time. For ordering, "
            "assignment, counting or arithmetic, test both exactly with the python function. Then "
            "reply with 'ANSWER: <the answer that satisfies every rule>' (A, B, or a corrected "
            "answer), in the exact output format."
        )

    def build_final_prompt(self, ctx: ChallengeContext) -> str:
        return (
            "Time is almost up. Using everything above, reply now with only "
            "'ANSWER: <final answer>' in the exact format the rules require."
        )

    # ---- submit policy ---------------------------------------------------

    def should_submit_early(self, answer: str, ctx: ChallengeContext) -> bool:
        # Speed is scored from GO: submit the first well-formed answer.
        return bool(str(answer or "").strip())

    def on_time_warning(self, remaining_s: float, current_answer: str, ctx: ChallengeContext) -> str | None:
        return current_answer or None

    # ---- images ----------------------------------------------------------

    def plan_image_tool(self, ctx: ChallengeContext, available_tools: list[str]) -> str:
        if ctx.image_url and "image_edit" in available_tools:
            return "image_edit"
        if "image_generate" in available_tools:
            return "image_generate"
        if ctx.image_url and "image_edit" not in available_tools and "image_analyze" in available_tools:
            return "image_analyze"
        return ""

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        # The judge scores edits on accuracy, quality, preservation and compliance, and
        # generations on quality, prompt match and constraints. Measured on Practice: for
        # edits the short preservation sentence below scored best (88.7, preservation 78);
        # every longer list of things to keep scored lower (82.5-86.7). For generations the
        # explicit no-text rule lifted constraints from 70 to 84 (final 88.45 -> 92.25).
        instruction = ctx.rules.strip() or ctx.challenge_text.strip() or ctx.description.strip()
        context = ctx.description.strip()
        lines = [instruction]
        if context and context not in instruction:
            lines.append(f"Context: {context}")
        if ctx.image_url:
            lines.append(
                "Apply exactly the requested change. Keep everything else in the source image "
                "unchanged: composition, subjects, colors, lighting and framing."
            )
        else:
            lines.append(
                "Treat every constraint in the request as a hard rule (count, colors, layout, "
                "style, exclusions). Single coherent scene, clean composition."
            )
        blob = f"{instruction} {context}".lower()
        if any(s in blob for s in ("no text", "without text", "no words", "no lettering", "no logo", "watermark")):
            lines.append(
                "Absolutely no text anywhere: no letters, words, numbers, captions, signage, "
                "logos or watermarks. Signs, screens and neon must show only abstract shapes "
                "and light, never characters."
            )
        lines.append(
            "Standard resolution only (about 1024 px on the longest side); no HD, 4K or upscaling."
        )
        return "\n\n".join(line for line in lines if line)
