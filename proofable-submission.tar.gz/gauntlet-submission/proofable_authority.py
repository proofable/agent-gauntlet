"""Proofable's authority engine (authority-policy.v2), ported line for line to Python.

Every constant is loaded from ``proofable_authority_contract.json``: the subset of
Proofable's authority contract this agent evaluates (capability classes and verbs, the
delegation vocabulary, and the code-execution classification), with the source commit and
the SHA-256 of the full contract it was cut from. Decision parity with Proofable's
JavaScript engine is tested against the full contract, case by case, on every field.

JavaScript truthiness and coercion are reproduced where they change a decision (an empty
object is truthy; ``String(x || '')``; ``Number.isFinite`` only accepts numbers; ``BigInt``
string parsing). Pure and dependency-free, like the original.
"""

from __future__ import annotations

import json
import math
import re
import time
from pathlib import Path
from typing import Any

_CONTRACT_PATH = Path(__file__).resolve().with_name("proofable_authority_contract.json")
CONTRACT: dict[str, Any] = {}


def configure(contract: dict[str, Any]) -> None:
    """Load the engine's constants from an authority contract (the shipped one by default)."""
    global CONTRACT, AUTHORITY_POLICY_VERSION, AUTHORITY_OUTCOMES, AUTHORITY_RESOLUTION_TIMEOUT_MS
    global CANONICAL_DELEGATION_ACTIONS, _CANONICAL_ACTION_SET, SPEND_BEARING_ACTIONS, _SPEND_BEARING_SET
    global JOB_RUNTIME_DENIED_ACTIONS, DELEGATION_MODE_ALLOWED_TOOLS, DEFAULT_CLASSIFICATION, TOOL_POLICY
    global CAPABILITY_TOOL_NAMES, _DYNAMIC_PROOF_TOOL_PREFIX, _CLASS_POLICY, _UNKNOWN_CLASS
    global _VERB_CLASSES, _SAFE_HTTP_METHODS, _DESTRUCTIVE_HTTP_METHODS
    CONTRACT = contract
    AUTHORITY_POLICY_VERSION = contract["policyVersion"]
    AUTHORITY_OUTCOMES = list(contract["outcomes"])
    AUTHORITY_RESOLUTION_TIMEOUT_MS = int(contract["resolutionTimeoutMs"])
    CANONICAL_DELEGATION_ACTIONS = list(contract["canonicalDelegationActions"])
    _CANONICAL_ACTION_SET = set(CANONICAL_DELEGATION_ACTIONS)
    SPEND_BEARING_ACTIONS = list(contract["spendBearingActions"])
    _SPEND_BEARING_SET = set(SPEND_BEARING_ACTIONS)
    JOB_RUNTIME_DENIED_ACTIONS = set(contract["jobRuntimeDeniedActions"])
    DELEGATION_MODE_ALLOWED_TOOLS = set(contract["delegationModeAllowedTools"])
    DEFAULT_CLASSIFICATION = dict(contract["defaultClassification"])
    TOOL_POLICY = dict(contract["toolPolicy"])
    CAPABILITY_TOOL_NAMES = set(contract["capabilityToolNames"])
    _DYNAMIC_PROOF_TOOL_PREFIX = str(contract.get("dynamicProofToolPrefix") or "")
    _CLASS_POLICY = dict(contract["capabilityClassPolicy"])
    _UNKNOWN_CLASS = contract["capabilityUnknownClass"]
    _VERB_CLASSES = dict(contract["capabilityVerbClasses"])
    _SAFE_HTTP_METHODS = list(contract["capabilitySafeHttpMethods"])
    _DESTRUCTIVE_HTTP_METHODS = list(contract["capabilityDestructiveHttpMethods"])


configure(json.loads(_CONTRACT_PATH.read_text(encoding="utf-8")))


# ── JavaScript semantics ─────────────────────────────────────────────────────


def _truthy(value: Any) -> bool:
    if value is None or value is False:
        return False
    if isinstance(value, bool):
        return True
    if isinstance(value, (int, float)):
        return not (value == 0 or (isinstance(value, float) and math.isnan(value)))
    if isinstance(value, str):
        return value != ""
    return True  # objects and arrays, empty or not


def _js_str(value: Any) -> str:
    """``String(value)`` for the JSON value types the engine meets."""
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, float):
        if math.isnan(value):
            return "NaN"
        if value.is_integer():
            return str(int(value))
        return repr(value)
    if isinstance(value, list):
        return ",".join("" if v is None else _js_str(v) for v in value)
    if isinstance(value, dict):
        return "[object Object]"
    return str(value)


def _str_or_empty(value: Any) -> str:
    """``String(value || '')``."""
    return _js_str(value) if _truthy(value) else ""


def _get(obj: Any, key: str) -> Any:
    """``obj && obj.key`` for JSON values: only objects carry properties."""
    if isinstance(obj, dict):
        return obj.get(key)
    return None


def _is_finite_number(value: Any) -> bool:
    """``Number.isFinite(value)``: true only for finite numbers, never strings or booleans."""
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _to_number(value: Any) -> float:
    """``Number(value)``."""
    if value is None:
        return 0.0
    if value is True:
        return 1.0
    if value is False:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        text = value.strip()
        if text == "":
            return 0.0
        try:
            if re.fullmatch(r"0[xX][0-9a-fA-F]+", text):
                return float(int(text, 16))
            if re.fullmatch(r"0[oO][0-7]+", text):
                return float(int(text, 8))
            if re.fullmatch(r"0[bB][01]+", text):
                return float(int(text, 2))
            if re.fullmatch(r"[+-]?(Infinity|\d+\.?\d*([eE][+-]?\d+)?|\.\d+([eE][+-]?\d+)?)", text):
                return float(text.replace("Infinity", "inf"))
        except ValueError:
            pass
        return math.nan
    return math.nan


def _bigint(text: str) -> int | None:
    """``BigInt(text)`` for a string; None where JavaScript throws."""
    s = text.strip()
    if s == "":
        return 0
    if re.fullmatch(r"0[xX][0-9a-fA-F]+", s):
        return int(s, 16)
    if re.fullmatch(r"0[oO][0-7]+", s):
        return int(s, 8)
    if re.fullmatch(r"0[bB][01]+", s):
        return int(s, 2)
    if re.fullmatch(r"[+-]?\d+", s):
        return int(s)
    return None


# ── tool classification ──────────────────────────────────────────────────────


def is_known_tool(name: Any) -> bool:
    key = _str_or_empty(name).strip()
    if key in TOOL_POLICY:
        return True
    if key in CAPABILITY_TOOL_NAMES:
        return True
    # An empty prefix (the shipped subset carries none) must not make every name known.
    return bool(_DYNAMIC_PROOF_TOOL_PREFIX) and key.startswith(_DYNAMIC_PROOF_TOOL_PREFIX)


def capability_authority_mode(name: Any, args: Any) -> str | None:
    if _str_or_empty(name).strip() not in CAPABILITY_TOOL_NAMES or not _truthy(args):
        return None
    policy = _CLASS_POLICY.get(resolve_capability_execution_class(args)) or _CLASS_POLICY.get(_UNKNOWN_CLASS)
    mode = policy.get("authorityMode") if policy else None
    return mode if mode in ("auto", "notify", "approve", "never") else None


def deferred_context_reason(args: Any) -> str | None:
    if _get(args, "requiresMoreContext") is True:
        return "Waiting for the missing context before this action can be scoped."
    connection_id = _str_or_empty(_get(args, "connectionId")).strip()
    candidates = _to_number(_get(args, "connectionCandidates")) if _truthy(args) else math.nan
    if not connection_id and math.isfinite(candidates) and candidates > 1:
        return "Select which connected account to use before this action can run."
    return None


def _capability_class_from_slug(tool_slug: Any) -> str | None:
    tokens = [t for t in re.split(r"[^A-Z0-9]+", _str_or_empty(tool_slug).strip().upper()) if t]
    if not tokens:
        return None
    for token in tokens:
        if token in _VERB_CLASSES["destructive"]:
            return "destructive"
    for token in tokens:
        if token in _VERB_CLASSES["read"]:
            return "read"
    return None


def resolve_capability_execution_class(args: Any) -> str:
    method = _str_or_empty(_get(args, "method")).strip().upper()
    if method:
        if method in _DESTRUCTIVE_HTTP_METHODS:
            return "destructive"
        if method in _SAFE_HTTP_METHODS:
            return "read"
        return "send"
    return _capability_class_from_slug(_get(args, "toolSlug")) or _UNKNOWN_CLASS


def classify_tool(name: Any, args: Any) -> dict[str, Any]:
    key = _str_or_empty(name).strip()
    if key in CAPABILITY_TOOL_NAMES and _truthy(args):
        return _CLASS_POLICY[resolve_capability_execution_class(args)]
    return TOOL_POLICY.get(key) or DEFAULT_CLASSIFICATION


# ── normalization ────────────────────────────────────────────────────────────


def normalize_action(value: Any) -> str:
    return _str_or_empty(value).strip().lower()


def normalize_action_list(values: Any) -> list[str]:
    if not isinstance(values, list):
        return []
    return [a for a in (normalize_action(v) for v in values) if a]


def normalize_surface(value: Any) -> str:
    normalized = ("" if value is None else _js_str(value)).strip().lower()
    if not normalized:
        return "chat"
    return "chat" if normalized == "chat" else "job"


def normalize_response_mode(value: Any) -> str:
    normalized = ("" if value is None else _js_str(value)).strip().lower()
    if not normalized:
        return "agent"
    if normalized in ("agent", "plan", "delegation"):
        return normalized
    return "plan"


# ── delegation ───────────────────────────────────────────────────────────────


def delegation_permits_action(delegation: Any, action: Any) -> bool:
    if not _truthy(delegation):
        return False
    normalized = normalize_action(action)
    if not normalized or normalized not in _CANONICAL_ACTION_SET:
        return False
    if normalized in normalize_action_list(_get(delegation, "deniedActions")):
        return False
    allowed_raw = _get(delegation, "allowedActions")
    if not isinstance(allowed_raw, list):
        return True
    allowed = normalize_action_list(allowed_raw)
    if not allowed:
        return False
    return normalized in allowed


def _max_spend(policy: Any) -> int | None:
    raw = _get(policy, "maxSpend")
    if not _truthy(policy) or not _truthy(raw):
        return None
    value = _bigint(_js_str(raw))
    if value is None:
        return None
    return value if value >= 0 else None


# ── AARM R4 outcomes ─────────────────────────────────────────────────────────


def resolve_authorization_outcome(decision: Any) -> str:
    if not _truthy(decision):
        return "DENY"
    if _truthy(_get(decision, "outcome")):
        return decision["outcome"]
    if _get(decision, "decision") == "deny":
        return "STEP_UP" if _get(decision, "code") == "HUMAN_APPROVAL_REQUIRED" else "DENY"
    return "ALLOW"


def resolve_timed_out_authorization(outcome: str, requested_at_ms: float, now_ms: float | None = None, timeout_ms: float | None = None) -> str:
    timeout = timeout_ms if _is_finite_number(timeout_ms) and timeout_ms > 0 else AUTHORITY_RESOLUTION_TIMEOUT_MS
    now = now_ms if _is_finite_number(now_ms) else time.time() * 1000
    elapsed = now - requested_at_ms if _is_finite_number(requested_at_ms) else math.nan
    if not math.isfinite(elapsed) or elapsed < timeout:
        return outcome if math.isfinite(elapsed) else "DENY"
    return "DENY"


# ── the engine ───────────────────────────────────────────────────────────────


def _deny(code: str, message: str, **extra: Any) -> dict[str, Any]:
    return {"decision": "deny", "code": code, "message": message, **extra}


def evaluate_authority(input: Any) -> dict[str, Any]:
    """The one authority decision. Same input and output shape as the JavaScript engine."""
    name = _str_or_empty(_get(input, "name")).strip()
    args = _get(input, "args")
    context_raw = _get(input, "context")
    context = context_raw if _truthy(context_raw) else {}
    classification = classify_tool(name, args)
    action = classification["action"]
    risk = classification["risk"]
    tier = _get(input, "tier")

    def audit(decision: str, reason: str, code: str | None) -> dict[str, Any]:
        return {
            "tool": name,
            "action": action,
            "risk": risk,
            "decision": "allow" if decision == "allow" else "deny",
            "reason": reason,
            "code": code or None,
            "outcome": None,
            "tenant": _get(context, "tenant") if _truthy(_get(context, "tenant")) else None,
            "actorTenant": _get(context, "actorTenant") if _truthy(_get(context, "actorTenant")) else None,
            "actor": _get(context, "actor") if _truthy(_get(context, "actor")) else None,
            "tier": tier if _truthy(tier) else None,
            "surface": normalize_surface(_get(input, "surface")),
            "gatewayReachable": _get(context, "gatewayReachable") is not False,
        }

    def finish(result: dict[str, Any], reason: str) -> dict[str, Any]:
        outcome = resolve_authorization_outcome(result)
        record = audit(result["decision"], reason, result.get("code"))
        record["outcome"] = outcome
        out: dict[str, Any] = {"decision": result["decision"], "outcome": outcome}
        if _truthy(result.get("code")):
            out["code"] = result["code"]
        if _truthy(result.get("message")):
            out["message"] = result["message"]
        out.update({"reason": reason, "action": action, "risk": risk, "audit": record})
        return out

    # 0. Gateway fail-mode discipline.
    if _get(context, "gatewayReachable") is False:
        fail_mode = "fail_open" if _get(context, "failMode") == "fail_open" else "fail_closed"
        allowed = fail_mode == "fail_open"
        reason = f"{fail_mode}_no_gateway"
        result = finish(
            {"decision": "allow"}
            if allowed
            else _deny("GATEWAY_UNREACHABLE", "The authority service is unreachable; refusing until it recovers."),
            reason,
        )
        if allowed:
            result["audit"]["decision"] = "flag"
        return result

    # 1. Unknown tool names are denied before any policy branch.
    if not is_known_tool(name):
        return finish(_deny("NEUS_TOOL_UNKNOWN", "That tool is not available in this session."), "unknown_tool")

    surface = normalize_surface(_get(input, "surface"))
    response_mode = normalize_response_mode(_get(input, "responseMode"))

    # 2. Agent-team mode: the operator is a router only.
    if response_mode == "delegation" and name not in DELEGATION_MODE_ALLOWED_TOOLS:
        return finish(
            _deny("NEUS_DELEGATION_MODE_BLOCKED", "Agent team mode routes every task to one of your agents."),
            "delegation_mode_blocked",
        )

    # 3. Plan mode blocks high-risk actions.
    if response_mode == "plan" and risk == "high":
        return finish(_deny("NEUS_PLAN_MODE_BLOCKED", "Switch to Operator to run this action."), "plan_mode_blocked")

    # 3b. Capability authority mode: `never` refuses before side effects.
    if capability_authority_mode(name, args) == "never":
        return finish(
            _deny("NEUS_CAPABILITY_AUTHORITY_NEVER", "This connected-account action is not allowed to run."),
            "capability_authority_never",
        )

    # 4. Tenant binding.
    if _get(context, "tenant") is not None and _get(context, "actorTenant") != _get(context, "tenant"):
        return finish(_deny("CROSS_TENANT_DENIED", "An actor may only act inside its own tenant."), "cross_tenant_denied")

    # 4b. Declared workspace policy.
    if _get(context, "policyPermission") == "deny":
        return finish(_deny("POLICY_DENIED", "Workspace policy denies this action."), "policy_denied")

    # 5. Scope inheritance and delegation narrowing.
    scopes = normalize_action_list(_get(context, "scopes"))
    required_scopes = normalize_action_list(_get(context, "toolRequiredScopes"))
    if required_scopes:
        delegated = normalize_action_list(_get(context, "delegatedScopes"))
        effective = [s for s in scopes if not delegated or s in delegated]
        missing = [s for s in required_scopes if s not in effective]
        if missing:
            return finish(_deny("SCOPE_DENIED", f"Missing required scope: {', '.join(missing)}."), "scope_denied")

    delegation = _get(input, "delegation")

    # 6. Job surface.
    if surface == "job":
        if action in JOB_RUNTIME_DENIED_ACTIONS:
            return finish(
                _deny("JOB_SETUP_BLOCKED", "This job cannot create or revoke saved keys while it runs."),
                "job_setup_blocked",
            )
        if not _truthy(delegation):
            return finish(
                _deny("JOB_DELEGATION_REQUIRED", "This job needs a current agent delegation before it can run tools."),
                "job_delegation_required",
            )

    # 7. Spend cap.
    if _truthy(delegation) and action in _SPEND_BEARING_SET:
        if _max_spend(delegation) == 0:
            return finish(
                _deny("NEUS_SPEND_CAP_EXCEEDED", "This agent isn't allowed to spend or send on your behalf."),
                "spend_cap_exceeded",
            )

    # 8. Human-approval gate.
    if tier != "admin" and _truthy(delegation):
        needs_approval = _get(delegation, "requiresHumanApproval") is True and risk == "high"
        if needs_approval and _get(input, "humanApprovalGranted") is not True:
            return finish(
                {
                    "decision": "deny",
                    "code": "HUMAN_APPROVAL_REQUIRED",
                    "message": "This agent needs your approval before it can run this sensitive action.",
                    "requestedAtMs": time.time() * 1000,
                },
                "human_approval_required",
            )

    # 9. Delegation allow/deny.
    if _truthy(delegation):
        if action in normalize_action_list(_get(delegation, "deniedActions")):
            return finish(_deny("NEUS_TOOL_NOT_PERMITTED", "This agent isn't allowed to do that."), "delegation_denied")
        if surface == "job" or tier != "admin":
            if not delegation_permits_action(delegation, action):
                return finish(_deny("NEUS_TOOL_NOT_PERMITTED", "This agent isn't allowed to do that."), "delegation_denied")

    # 10. Per-user rate limit.
    rate_limit_raw = _get(context, "rateLimit")
    rate_used_raw = _get(context, "rateUsed")
    rate_limit = float(rate_limit_raw) if _is_finite_number(rate_limit_raw) else None
    rate_used = float(rate_used_raw) if _is_finite_number(rate_used_raw) else 0.0
    if rate_limit is not None and rate_used >= rate_limit:
        return finish(_deny("RATE_LIMITED", "This action is over its rate limit."), "rate_limited")

    # 11. DEFER: an ambiguous request is suspended, not guessed.
    defer_reason = deferred_context_reason(args)
    if defer_reason:
        return finish(
            {
                "decision": "deny",
                "outcome": "DEFER",
                "code": "NEUS_AUTHORITY_DEFERRED",
                "message": defer_reason,
                "deferReason": defer_reason,
                "requestedAtMs": time.time() * 1000,
            },
            "deferred",
        )

    return finish({"decision": "allow"}, "allowed")
