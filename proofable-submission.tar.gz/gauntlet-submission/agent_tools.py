"""Function-calling bridge between the LLM and the arena's MCP server.

Turns discovered MCP tools, resources and prompts into OpenAI function
definitions, renders MCP results as text, and runs model-written Python in a
bounded child process (decoding, decryption, arithmetic).
"""

from __future__ import annotations

import asyncio
import base64
import copy
import json
import os
import re
import sys
import tempfile
from dataclasses import dataclass, field
from typing import Any

# Tools the runtime drives itself; the model never sees them as functions.
HANDLED_TOOLS = frozenset(
    {
        "arena.get_challenge",
        "arena.clues.list",
        "arena.clues.get",
        "arena.time_remaining",
        "arena.image.get_challenge",
        "arena.image.broadcast_thought",
        "arena.image.submit_edit",
    }
)
# Never offered to the model: the runtime owns submission and the session.
_NEVER_OFFER = re.compile(r"(submit|register|broadcast|disconnect|leave|forfeit|give_?up)", re.I)
# Zero-argument tools with these names are read-only lookups worth probing up front.
_PROBE_OK = re.compile(
    r"(list|get|help|info|describe|read|show|hint|clue|discover|catalog|inspect|status|"
    r"manifest|schema|metadata|about|rules|docs?|capabilit|hidden|secret|key|whoami|"
    r"inventory|explore|index|readme)",
    re.I,
)
_PROBE_DENY = re.compile(
    r"(submit|answer|reset|delete|remove|clear|guess|solve|attempt|verify|check|unlock|"
    r"decrypt|buy|spend|pay|register|broadcast|forfeit|give_?up|time_remaining|"
    r"image_|generate|edit)",
    re.I,
)

PYTHON_FUNCTION = "python"
MCP_CALL_FUNCTION = "mcp_call_tool"
READ_RESOURCE_FUNCTION = "mcp_read_resource"
GET_PROMPT_FUNCTION = "mcp_get_prompt"

PYTHON_TIMEOUT_S = 10.0
PYTHON_MEMORY_BYTES = 768 * 1024 * 1024
PYTHON_OUTPUT_CHARS = 8000


def function_name(tool_name: str, taken: set[str]) -> str:
    """OpenAI-safe function name (^[a-zA-Z0-9_-]{1,64}$), unique within ``taken``."""
    base = re.sub(r"[^a-zA-Z0-9_-]", "_", tool_name).strip("_") or "tool"
    base = base[:60]
    name = base
    counter = 2
    while name in taken:
        suffix = f"_{counter}"
        name = base[: 64 - len(suffix)] + suffix
        counter += 1
    taken.add(name)
    return name


def _clean_schema(schema: Any) -> dict[str, Any]:
    if not isinstance(schema, dict):
        return {"type": "object", "properties": {}}
    cleaned = copy.deepcopy(schema)
    for key in ("$schema", "title", "$id"):
        cleaned.pop(key, None)
    if cleaned.get("type") != "object":
        cleaned["type"] = "object"
    props = cleaned.get("properties")
    if not isinstance(props, dict):
        cleaned["properties"] = {}
    return cleaned


def schema_without_agent_id(schema: Any) -> tuple[dict[str, Any], bool]:
    """Drop ``agent_id`` from a tool schema; the runtime injects it."""
    cleaned = _clean_schema(schema)
    props = cleaned["properties"]
    takes_agent_id = "agent_id" in props
    if takes_agent_id:
        props.pop("agent_id", None)
        required = cleaned.get("required")
        if isinstance(required, list):
            cleaned["required"] = [r for r in required if r != "agent_id"]
            if not cleaned["required"]:
                cleaned.pop("required")
    return cleaned, takes_agent_id


def required_params(schema: Any) -> list[str]:
    if not isinstance(schema, dict):
        return []
    required = schema.get("required")
    if not isinstance(required, list):
        return []
    return [str(r) for r in required if str(r) != "agent_id"]


def _strings(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, dict):
        return [s for v in value.values() for s in _strings(v)]
    if isinstance(value, list):
        return [s for v in value for s in _strings(v)]
    return []


def is_uninformative(text: str, known_tools: set[str]) -> bool:
    """True when a probe result only repeats tool names we already know.

    A tool listing that names nothing new invites the model to re-fetch data
    it already has, so it is left out of the prompt.
    """
    first = text.split("\n{", 1)[0].strip() if text.startswith("{") else text.strip()
    try:
        data = json.loads(first)
    except (TypeError, ValueError):
        return False
    strings = _strings(data)
    return bool(strings) and all(s in known_tools for s in strings)


def is_probe_candidate(tool_name: str, schema: Any) -> bool:
    """Zero-argument, read-only-looking tool worth calling before the first LLM turn."""
    if tool_name in HANDLED_TOOLS or required_params(schema):
        return False
    if _PROBE_DENY.search(tool_name):
        return False
    return bool(_PROBE_OK.search(tool_name))


@dataclass
class FunctionTable:
    """OpenAI ``tools`` payload plus the mapping back to MCP tool names."""

    tools: list[dict[str, Any]] = field(default_factory=list)
    mcp_names: dict[str, str] = field(default_factory=dict)  # function -> MCP tool
    injects_agent_id: dict[str, bool] = field(default_factory=dict)  # MCP tool -> bool


def build_function_table(
    tool_defs: list[Any],
    *,
    modality: str,
    has_resources: bool,
    has_prompts: bool,
) -> FunctionTable:
    table = FunctionTable()
    taken: set[str] = {PYTHON_FUNCTION, MCP_CALL_FUNCTION, READ_RESOURCE_FUNCTION, GET_PROMPT_FUNCTION}
    for tool in tool_defs:
        name = str(getattr(tool, "name", "") or "").strip()
        if not name:
            continue
        schema, takes_agent_id = schema_without_agent_id(getattr(tool, "inputSchema", None))
        table.injects_agent_id[name] = takes_agent_id
        if name in HANDLED_TOOLS or _NEVER_OFFER.search(name):
            continue
        if modality == "text" and name in {"image_edit", "image_generate"}:
            continue
        fname = function_name(name, taken)
        description = str(getattr(tool, "description", "") or "").strip()
        if fname != name:
            description = f"[MCP tool '{name}'] {description}".strip()
        table.mcp_names[fname] = name
        table.tools.append(
            {
                "type": "function",
                "function": {
                    "name": fname,
                    "description": description[:1024] or f"MCP tool {name}",
                    "parameters": schema,
                },
            }
        )

    table.tools.append(
        {
            "type": "function",
            "function": {
                "name": PYTHON_FUNCTION,
                "description": (
                    "Run Python 3.12 code and return its stdout/stderr. Use print() for output. "
                    "Standard library plus the 'cryptography' package. Good for decoding "
                    "(base64, hex, rot13, Caesar, XOR), decryption, math, counting and search. "
                    f"Times out after {int(PYTHON_TIMEOUT_S)} s. No network."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {"code": {"type": "string", "description": "Python source"}},
                    "required": ["code"],
                },
            },
        }
    )
    table.tools.append(
        {
            "type": "function",
            "function": {
                "name": MCP_CALL_FUNCTION,
                "description": (
                    "Call any MCP tool by its exact name, including hidden or unlisted tools "
                    "mentioned in challenge text, clues or other tool results."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "description": "Exact MCP tool name"},
                        "arguments": {
                            "type": "object",
                            "description": "Tool arguments as a JSON object",
                        },
                    },
                    "required": ["name"],
                },
            },
        }
    )
    if has_resources:
        table.tools.append(
            {
                "type": "function",
                "function": {
                    "name": READ_RESOURCE_FUNCTION,
                    "description": "Read an MCP resource by URI (see the resource list in the task).",
                    "parameters": {
                        "type": "object",
                        "properties": {"uri": {"type": "string"}},
                        "required": ["uri"],
                    },
                },
            }
        )
    if has_prompts:
        table.tools.append(
            {
                "type": "function",
                "function": {
                    "name": GET_PROMPT_FUNCTION,
                    "description": "Fetch an MCP prompt by name with optional string arguments.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "arguments": {"type": "object"},
                        },
                        "required": ["name"],
                    },
                },
            }
        )
    return table


def render_call_result(result: Any) -> str:
    """Flatten an MCP CallToolResult into text the model can read."""
    parts: list[str] = []
    structured = getattr(result, "structuredContent", None)
    if structured is not None:
        try:
            parts.append(json.dumps(structured, ensure_ascii=False, default=str))
        except (TypeError, ValueError):
            parts.append(str(structured))
    for item in getattr(result, "content", None) or []:
        kind = getattr(item, "type", "")
        if kind == "text":
            text = str(getattr(item, "text", "") or "")
            if text and text not in parts:
                parts.append(text)
        elif kind == "image":
            mime = getattr(item, "mimeType", "image")
            data = str(getattr(item, "data", "") or "")
            parts.append(f"[image content {mime}, {len(data)} base64 chars]")
        elif kind == "resource":
            resource = getattr(item, "resource", None)
            text = getattr(resource, "text", None)
            uri = getattr(resource, "uri", "")
            if text:
                parts.append(f"[resource {uri}]\n{text}")
            else:
                blob = str(getattr(resource, "blob", "") or "")
                parts.append(f"[resource {uri}, {len(blob)} base64 chars]")
        else:
            parts.append(str(item))
    text = "\n".join(p for p in parts if p).strip()
    if getattr(result, "isError", False):
        text = f"ERROR: {text or 'tool reported an error'}"
    return text or "(empty result)"


def render_resource_result(result: Any) -> str:
    parts: list[str] = []
    for item in getattr(result, "contents", None) or []:
        text = getattr(item, "text", None)
        uri = getattr(item, "uri", "")
        if text is not None:
            parts.append(f"[{uri}]\n{text}")
            continue
        blob = str(getattr(item, "blob", "") or "")
        decoded = ""
        try:
            raw = base64.b64decode(blob, validate=False)
            decoded = raw.decode("utf-8")
        except Exception:
            decoded = ""
        parts.append(f"[{uri}]\n{decoded}" if decoded else f"[{uri}] binary, {len(blob)} base64 chars")
    return "\n".join(parts).strip() or "(empty resource)"


def render_prompt_result(result: Any) -> str:
    parts: list[str] = []
    description = getattr(result, "description", None)
    if description:
        parts.append(str(description))
    for message in getattr(result, "messages", None) or []:
        content = getattr(message, "content", None)
        text = getattr(content, "text", None)
        role = getattr(message, "role", "")
        parts.append(f"{role}: {text if text is not None else content}")
    return "\n".join(parts).strip() or "(empty prompt)"


def clip(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    head = limit * 3 // 4
    tail = limit - head - 40
    return f"{text[:head]}\n...[{len(text) - head - tail} chars cut]...\n{text[-tail:]}"


def _limit_child() -> None:  # pragma: no cover - runs in the child process
    try:
        import resource

        resource.setrlimit(resource.RLIMIT_AS, (PYTHON_MEMORY_BYTES, PYTHON_MEMORY_BYTES))
        cpu = int(PYTHON_TIMEOUT_S) + 2
        resource.setrlimit(resource.RLIMIT_CPU, (cpu, cpu))
    except Exception:
        pass


async def run_python(code: str, timeout_s: float = PYTHON_TIMEOUT_S) -> str:
    """Run model-written Python in a bounded child process; return its output."""
    code = str(code or "")
    if not code.strip():
        return "ERROR: empty code"
    workdir = tempfile.mkdtemp(prefix="py-", dir=tempfile.gettempdir())
    env = {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "HOME": workdir,
        "TMPDIR": workdir,
        "PYTHONIOENCODING": "utf-8",
        "PYTHONDONTWRITEBYTECODE": "1",
    }
    kwargs: dict[str, Any] = {}
    if os.name == "posix":
        kwargs["preexec_fn"] = _limit_child
    try:
        proc = await asyncio.create_subprocess_exec(
            sys.executable,
            "-I",
            "-c",
            code,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=workdir,
            env=env,
            **kwargs,
        )
    except Exception as exc:
        return f"ERROR: could not start python: {exc}"
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout_s)
    except asyncio.TimeoutError:
        proc.kill()
        try:
            await asyncio.wait_for(proc.communicate(), timeout=2.0)
        except Exception:
            pass
        return f"ERROR: timed out after {timeout_s:.0f} s"
    except asyncio.CancelledError:
        proc.kill()
        raise
    out = stdout.decode("utf-8", errors="replace").strip()
    err = stderr.decode("utf-8", errors="replace").strip()
    text = out
    if err:
        text = f"{out}\n[stderr]\n{err}" if out else f"[stderr]\n{err}"
    if proc.returncode not in (0, None) and not err:
        text = f"{text}\n[exit code {proc.returncode}]"
    return clip(text.strip() or "(no output; use print())", PYTHON_OUTPUT_CHARS)


_ANSWER_LINE = re.compile(r"^\s*[*_`>#\s]*(?:final\s+answer|answer)\s*[*_`]*\s*[:：]\s*(.+?)\s*$", re.I)


def extract_answer(text: str) -> str:
    """Last 'ANSWER: ...' (or 'Final answer: ...') line, cleaned of markdown."""
    if not text:
        return ""
    cleaned = re.sub(r"<think>.*?(?:</think>|$)", "", text, flags=re.DOTALL | re.IGNORECASE)
    found = ""
    for line in cleaned.splitlines():
        match = _ANSWER_LINE.match(line)
        if match:
            candidate = match.group(1).strip()
            candidate = re.sub(r"^(\*\*|__|`)+|(\*\*|__|`)+$", "", candidate).strip()
            if len(candidate) >= 2 and candidate[0] == candidate[-1] and candidate[0] in "\"'":
                candidate = candidate[1:-1].strip()
            if candidate and not is_bad_answer(candidate):
                found = candidate
    return found


def conform_answer(answer: str, output_format: str) -> str:
    """Match the separators of the challenge's output_format example.

    Measured on Practice: a correct order written "E3,E2,E5" against the
    format "E1, E2, E3" is a needless format risk with the judge.
    """
    text = str(answer or "").strip()
    fmt = str(output_format or "").strip()
    if not text or not fmt:
        return text
    if "," in fmt and "," in text:
        separator = ", " if ", " in fmt else ","
        text = re.sub(r"\s*,\s*", separator, text)
    if text.endswith(".") and not fmt.endswith("."):
        text = text[:-1].rstrip()
    return text


def same_answer_key(answer: str, output_format: str = "") -> str:
    """Comparison key: format-conformed, case- and whitespace-insensitive."""
    text = conform_answer(answer, output_format).lower()
    text = re.sub(r"\s+", " ", text).strip().strip("\"'`")
    return text.rstrip(".")


def _same_item(a: str, b: str) -> bool:
    if a == b:
        return True
    wa, wb = a.split(), b.split()
    short, long = (wa, wb) if len(wa) <= len(wb) else (wb, wa)
    # "Team Alpha" and "Alpha" name the same thing: one is the other with a qualifier.
    return bool(short) and (long[-len(short):] == short or long[: len(short)] == short)


def same_answer(a: str, b: str, output_format: str = "") -> bool:
    """Same answer up to format, case, spacing and a shared qualifier on list items.

    Measured on Practice: "Team Alpha, Team Bravo, ..." against "Alpha, Bravo, ..." is the
    same order, and treating it as a dispute cost a verification round.
    """
    if not a or not b:
        return False
    ka, kb = same_answer_key(a, output_format), same_answer_key(b, output_format)
    if ka == kb:
        return True
    ia = [x.strip() for x in ka.split(",")]
    ib = [x.strip() for x in kb.split(",")]
    return len(ia) > 1 and len(ia) == len(ib) and all(_same_item(x, y) for x, y in zip(ia, ib))


def is_bad_answer(value: str) -> bool:
    text = str(value or "").strip()
    if not text:
        return True
    lowered = text.lower()
    if lowered in {"unknown", "<final answer>", "final answer", "<answer>"}:
        return True
    if lowered.startswith(("<toolcall", "toolcall", "<think", "<tool_call", "{\"name\"")):
        return True
    return any(tok in lowered for tok in ("<toolcall", "</toolcall", '"tool_calls"', "function_call"))
